@echo off
chcp 65001 > nul
echo ============================================
echo  統一編號查詢工具 — 打包成 .exe
echo ============================================
echo.

:: 檢查 Python
python --version 2>nul
if errorlevel 1 (
    echo [錯誤] 找不到 Python，請先安裝 Python 3.9+
    echo 下載：https://www.python.org/downloads/
    pause
    exit /b 1
)

:: 安裝套件
echo [1/3] 安裝必要套件...
pip install selenium pillow pytesseract openpyxl pandas webdriver-manager pyinstaller --quiet
if errorlevel 1 (
    echo [錯誤] 套件安裝失敗
    pause
    exit /b 1
)

:: 檢查 Tesseract
where tesseract 2>nul
if errorlevel 1 (
    echo.
    echo [警告] 未偵測到 Tesseract OCR
    echo 請先安裝：https://github.com/UB-Mannheim/tesseract/wiki
    echo 安裝後請將 Tesseract 路徑加入系統 PATH
    echo 或在 einvoice_app.py 中設定：
    echo   pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    echo.
    pause
)

:: 打包 exe
echo [2/3] 打包 .exe 中（約需 1-3 分鐘）...
pyinstaller ^
  --onefile ^
  --windowed ^
  --name "統一編號查詢工具" ^
  --add-data "einvoice_app.py;." ^
  einvoice_app.py

if errorlevel 1 (
    echo [錯誤] 打包失敗，請查看上方錯誤訊息
    pause
    exit /b 1
)

echo.
echo [3/3] 完成！
echo 執行檔位於：dist\統一編號查詢工具.exe
echo.
pause
